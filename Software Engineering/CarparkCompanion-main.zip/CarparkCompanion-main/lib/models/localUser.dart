/// simple class file to create a User instance to identify the current user of the app

class LocalUser {
  final String? uid;

  LocalUser({this.uid});
}

# AI_CZ3005_Project2

Coding in Prolog

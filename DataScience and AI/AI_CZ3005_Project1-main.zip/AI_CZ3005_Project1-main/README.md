# AI_CZ3005_Project1
Search Algorithms

To RUN:
cd AI_CZ3005_Project1-main
python main.py

# DataScience-Project
Running machine learning to predict revenue of movies

Overall Project

Section 1: Imports and Data Extraction

Section 2: Data Cleaning and Exploratory Analysis

Section 3: Data Preprocessing

Section 4: Machine Learning Models

Section 5: Fine-tuning of Models

Section 6: Data insights on Revenue
